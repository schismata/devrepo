# -*- coding: utf-8 -*-

'''
    Exodus Add-on
    Copyright (C) 2016 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import re,unicodedata

def get_italian(title):
    
    title = re.sub('\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|', '', title).lower()
    title = re.sub('(&#[0-9]+)', '', title)
    title =re.sub(r'\ -',r'', title)
    title = title.replace(":","")
    title = re.sub('&',' ', title)
    title = re.sub("'"," ", title)
    title = re.compile("\s+",re.DOTALL).sub(" ",title)
    title = re.sub('[^A-Za-z0-9\s]+', '', title).lower()
    title = re.sub(' ','', title).lower()				
    title = normalize(title)			

    return title

def get(title):
    if title == None: return
    title = re.sub('(&#[0-9]+)([^;^0-9]+)', '', title)
    title = title.replace('&quot;', '\"').replace('&amp;', '&')
    title = re.sub('\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|(:|;|-|"|,|\'|\_|\.|\?)|\s', '', title).lower()
    title = re.sub('\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|', '', title).lower()
    title = re.sub('(&#[0-9]+)', '', title)
    title =re.sub(r'\ -',r'', title)
    title = title.replace(":","")

    return title


def normalize(title):
    try:
        try: return title.decode('ascii').encode("utf-8")
        except: pass

        t = ''
        for i in title:
            c = unicodedata.normalize('NFKD',unicode(i,"ISO-8859-1"))
            c = c.encode("ascii","ignore").strip()
            if i == ' ': c = i
            t += c

        return t.encode("utf-8")
    except:
        return title

