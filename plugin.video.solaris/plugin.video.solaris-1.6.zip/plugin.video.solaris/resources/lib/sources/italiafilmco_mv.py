# -*- coding: utf-8 -*-

'''
    Exodus Add-on
    Copyright (C) 2016 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
##### HD GRATIS #####

import urllib,urllib2,re,sys,xbmc,xbmcaddon,os,urlparse,base64,net,cf,json
from t0mm0.common.addon import Addon
from metahandler import metahandlers
net = net.Net()
addon_id = 'plugin.video.solaris'
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
addon = Addon(addon_id, sys.argv)
try:os.mkdir(datapath)
except:pass
file_var = open(xbmc.translatePath(os.path.join(datapath, 'italiafilmco_cookie.lwp')), "a")
cookie_file = os.path.join(os.path.join(datapath,''), 'italiafilmco_cookie.lwp')

from resources.lib.modules import cleantitle
from resources.lib.modules import cloudflare
from resources.lib.modules import client
import unicodedata
domain = 'ITALIAFILMCO'

class source:
    def __init__(self):
        self.domains = ['italia-film.co']
        self.base_link = 'http://www.italia-film.co'
        self.watch_link = ''
        self.search_link = '/?s=%s'


    def movie(self, imdb, title, year):
        try:
            query = self.search_link % urllib.quote_plus(title)
            query = urlparse.urljoin(self.base_link, query)

            result = open_url(query)
            title = cleantitle.get(title)  
            result=re.compile('<h3 class="entry-title"><a href="(.+?)" rel="bookmark">(.+?)</a></h3>').findall(result)
            print 'SOLARIS SEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEARCH = %s ' % title
            for url,name in result:
				name = cleantitle.get_italian(name)
				print 'SOLARIS ; %s -> SCRAPED TITLE = %s' % (domain, name)
				if title in name: 
					print 'SOLARIS UUUUUUUUUUUUUUUUUUUUUUUUUUUUUURL =%s ' % url
					return url
        except:
            return

    def sources(self, url, hosthdDict, hostprDict):
        try:
            sources = []
            if url == None: return sources
            result = open_url(url)
            match2 = re.compile('src="http://hdlink.video/(.+?)" width=', re.DOTALL).findall(result)
            match = re.compile('<a href="(.+?)" target="_blank">(.+?)</a>').findall(result)
            for url,name in match:
				if "part" not in name:
					if "Part" not in name:
						if "italia-film" not in url:
							if "youtube" not in url:
								if "adk2x.com" not in url:
									if "keeplink" not in url:
										print 'SOLARIS FOUND VIDEO UUUUUUUUUUUUUUUUUUUUUUUUUUUUUURL =%s ' % url
										host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
										host = client.replaceHTMLCodes(host)
										host = host.encode('utf-8')
										url = client.replaceHTMLCodes(url)
										url = url.encode('utf-8')
										quality = 'SD'
										sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
            for url in match2:
					iframe = "http://hdlink.video/" + url
					try:
						new_url = iframe + "?host=1#"
						result = client.request(new_url)
						match = re.compile('<script type="text/javascript" src="(.+?)">', re.DOTALL).findall(result)
						match2 = re.compile('<iframe src="(.+?)" scrolling=', re.DOTALL).findall(result)
						match4 = re.compile('<iframe src="(.+?)" frameborder=', re.DOTALL).findall(result)
						match3 = re.compile('<IFRAME SRC="(.+?)" FRAMEBORDER=', re.DOTALL).findall(result)
						for url in match:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match2:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match3:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match4:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
					except: pass

					try:
						new_url = iframe + "?host=2#"
						result = client.request(new_url)
						match = re.compile('<script type="text/javascript" src="(.+?)">', re.DOTALL).findall(result)
						match2 = re.compile('<iframe src="(.+?)" scrolling=', re.DOTALL).findall(result)
						match4 = re.compile('<iframe src="(.+?)" frameborder=', re.DOTALL).findall(result)
						match3 = re.compile('<IFRAME SRC="(.+?)" FRAMEBORDER=', re.DOTALL).findall(result)
						for url in match:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match2:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match3:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match4:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
					except: pass

					try:
						new_url = iframe + "?host=3#"
						result = client.request(new_url)
						match = re.compile('<script type="text/javascript" src="(.+?)">', re.DOTALL).findall(result)
						match2 = re.compile('<iframe src="(.+?)" scrolling=', re.DOTALL).findall(result)
						match4 = re.compile('<iframe src="(.+?)" frameborder=', re.DOTALL).findall(result)
						match3 = re.compile('<IFRAME SRC="(.+?)" FRAMEBORDER=', re.DOTALL).findall(result)
						for url in match:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match2:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match3:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match4:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
					except: pass
					try:
						new_url = iframe + "?host=4#"
						result = client.request(new_url)
						match = re.compile('<script type="text/javascript" src="(.+?)">', re.DOTALL).findall(result)
						match2 = re.compile('<iframe src="(.+?)" scrolling=', re.DOTALL).findall(result)
						match4 = re.compile('<iframe src="(.+?)" frameborder=', re.DOTALL).findall(result)
						match3 = re.compile('<IFRAME SRC="(.+?)" FRAMEBORDER=', re.DOTALL).findall(result)
						for url in match:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match2:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match3:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match4:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
					except: pass
					try:
						new_url = iframe + "?host=5#"
						result = client.request(new_url)
						match = re.compile('<script type="text/javascript" src="(.+?)">', re.DOTALL).findall(result)
						match2 = re.compile('<iframe src="(.+?)" scrolling=', re.DOTALL).findall(result)
						match4 = re.compile('<iframe src="(.+?)" frameborder=', re.DOTALL).findall(result)
						match3 = re.compile('<IFRAME SRC="(.+?)" FRAMEBORDER=', re.DOTALL).findall(result)
						for url in match:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match2:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match3:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match4:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
					except: pass
					try:
						new_url = iframe + "?host=6#"
						result = client.request(new_url)
						match = re.compile('<script type="text/javascript" src="(.+?)">', re.DOTALL).findall(result)
						match2 = re.compile('<iframe src="(.+?)" scrolling=', re.DOTALL).findall(result)
						match4 = re.compile('<iframe src="(.+?)" frameborder=', re.DOTALL).findall(result)
						match3 = re.compile('<IFRAME SRC="(.+?)" FRAMEBORDER=', re.DOTALL).findall(result)
						for url in match:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match2:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match3:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match4:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
					except: pass
					try:
						new_url = iframe + "?host=7#"
						result = client.request(new_url)
						match = re.compile('<script type="text/javascript" src="(.+?)">', re.DOTALL).findall(result)
						match2 = re.compile('<iframe src="(.+?)" scrolling=', re.DOTALL).findall(result)
						match4 = re.compile('<iframe src="(.+?)" frameborder=', re.DOTALL).findall(result)
						match3 = re.compile('<IFRAME SRC="(.+?)" FRAMEBORDER=', re.DOTALL).findall(result)
						for url in match:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match2:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match3:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
						for url in match4:
							host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
							host = client.replaceHTMLCodes(host)
							host = host.encode('utf-8')
							url = client.replaceHTMLCodes(url)
							url = url.encode('utf-8')
							quality = 'SD'
							sources.append({'source': host, 'quality': quality, 'provider': 'Italiafilmco', 'url': url, 'direct': False, 'debridonly': False})
					except: pass


            return sources
        except:
            return sources 


    def resolve(self, url):
        return url

def open_url(url):
        try:
            net.set_cookies(cookie_file)
            link = net.http_GET(url).content
            return link
        except:
          try:
            cf.solve(url,cookie_file,wait=True)
            net.set_cookies(cookie_file)
            link = net.http_GET(url).content
            return link
          except:
            cf.solve(url,cookie_file,wait=True)
            net.set_cookies(cookie_file)
            link = net.http_GET(url).content
            return link