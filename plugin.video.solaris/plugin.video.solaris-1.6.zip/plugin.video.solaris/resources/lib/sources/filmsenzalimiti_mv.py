# -*- coding: utf-8 -*-

'''
    Exodus Add-on
    Copyright (C) 2016 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
##### FILMSENZALIMITI ########

import re,urllib,urlparse,random

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import cloudflare

class source:
    def __init__(self):
        self.domains = ['filmsenzalimiti.co']
        self.base_link = 'http://www.filmsenzalimiti.co'
        self.search_link = '/?s=%s'


    def movie(self, imdb, title, year):
        try:
            query = self.search_link % urllib.quote_plus(re.sub(' ', '+', title))
            query = urlparse.urljoin(self.base_link, query)

            result = client.source(query)
            result = result.decode('iso-8859-1').encode('utf-8')
            title = cleantitle.get(title)  

            result = client.parseDOM(result, 'div', attrs = {'class': 'post-item-side'})
            link = [(client.parseDOM(i, 'a', ret='href'), client.parseDOM(i, ret='title')) for i in result]
            
            for url,name in link:
				name = re.sub('\n|([[].+?[]])|([(].+?[)])|\s(vs|v[.])\s|', '', name)
				name = re.sub('(&#[0-9]+)', '', name)
				name = re.sub('[^A-Za-z0-9\s]+', '', name)
				name = re.sub(' ','', name).lower()
				if title in name:
					return url
        except:
            return	

    def sources(self, url, hosthdDict, hostprDict):
        try:
            sources = []
            if url == None: return sources
            result = client.source(url)
			
            playlink = re.compile('<a href="(.+?)" rel="nofollow" target="_blank" class="external"', re.DOTALL).findall(result)
            for url in playlink :
				host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
				host = client.replaceHTMLCodes(host)
				host = host.encode('utf-8')
				if "speedvideo" in url:
					quality = 'HD'
				else: quality = 'SD'
				sources.append({'source': host, 'quality': quality, 'provider': 'Filmsenzalimiti', 'url': url, 'direct': False, 'debridonly': False})
            return sources
        except:
            return sources 


    def resolve(self, url):
        return url

