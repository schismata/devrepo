# -*- coding: utf-8 -*-

'''
    Exodus Add-on
    Copyright (C) 2016 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

domain = 'CASACINEMA'
import re,urllib,urlparse,base64
import unicodedata
from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import italian_normalize

class source:
    def __init__(self):
        self.domains = ['casa-cinema.org']
        self.base_link = 'http://www.casa-cinema.org'
        self.moviesearch_link = '/?s=%s'
        
    def movie(self, imdb, title, year):
        try:
            query = self.moviesearch_link % urllib.quote_plus(title)
            query = urlparse.urljoin(self.base_link, query)

            result = client.source(query)
            result = result.decode('iso-8859-1').encode('utf-8')

            title = cleantitle.get(title)
            print 'SOLARIS SEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEARCH = %s ' % title
            
            match=re.compile('<a href="(.+?)" title="(.+?)" >').findall(result)
            for url,name in match:
				name = cleantitle.get_italian(name)
				
				if title in name: 
					print 'SOLARIS YEEEEEEEEEEEEEEEEEEEEEEE FOUND IT '
					url = url
					print 'SOLARIS UUUUUUUUUUUUUUUUUUUUUUUUUUUUUURL =%s ' % url
					return url
        except:
            return	

    def sources(self, url, hosthdDict, hostprDict):
        try:
            sources = []
            if url == None: return sources
            result = client.source(url)
            playlink2=re.compile("<a style='.+?' href='(.+?)' target='_blank'").findall(result)
            playlink = re.compile('<iframe class=".+?" SRC="(.+?)"').findall(result)
            playlink3 = re.compile('<iframe class=".+?" src="(.+?)"').findall(result)
            for url in playlink:
				host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
				host = client.replaceHTMLCodes(host)
				host = host.encode('utf-8')
				url = client.replaceHTMLCodes(url)
				url = url.encode('utf-8')
				
				if "speedvideo" in host:
					quality = 'HD'
				else: quality = 'SD'
				sources.append({'source': host, 'quality': quality, 'provider': 'Casacinema', 'url': url, 'direct': False, 'debridonly': False})
            for url in playlink2:
				host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
				host = client.replaceHTMLCodes(host)
				host = host.encode('utf-8')
				url = client.replaceHTMLCodes(url)
				url = url.encode('utf-8')

				if "speedvideo" in host:
					quality = 'HD'
				else: quality = 'SD'
				sources.append({'source': host, 'quality': quality, 'provider': 'Casacinema', 'url': url, 'direct': False, 'debridonly': False})
            for url in playlink3:
				host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
				host = client.replaceHTMLCodes(host)
				host = host.encode('utf-8')
				url = client.replaceHTMLCodes(url)
				url = url.encode('utf-8')

				if "speedvideo" in host:
					quality = 'HD'
				else: quality = 'SD'
				sources.append({'source': host, 'quality': quality, 'provider': 'Casacinema', 'url': url, 'direct': False, 'debridonly': False})
            return sources
        except:
            return sources 


    def resolve(self, url):
        return url

