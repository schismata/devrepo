import re
import unicodedata

def strip_char(title):
    """
    Strip accents from input String.

    :param title: The input string.
    :type title: String.

    :returns: The processed String.
    :rtype: String.
    """
    title =re.sub(r'\ -',r'', title)
    title = title.replace(":","")
    try: title = unicode(title, 'utf-8')
    except: pass
    title = unicodedata.normalize('NFD', title)
    title = title.encode('ascii', 'ignore')
    title = re.sub('&',' ', title)
    title = re.sub("'"," ", title)
    title = re.compile("\s+",re.DOTALL).sub(" ",title)
    title = title.encode('utf-8')

    return title