# -*- coding: utf-8 -*-

'''
    solaris Add-on
    Copyright (C) 2016 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
##### ITALIAFILMVIDEOHD ########

import re,urllib,urlparse,random,urllib2

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import cloudflare

class source:
    def __init__(self):
        self.domains = ['taliafilm.video']
        self.base_link = 'http://www.italiafilm.video'
        self.search_link = '/?s=%s'


    def movie(self, imdb, title, year):
        try:
            query = self.search_link % urllib.quote_plus(re.sub(' ', '+', title))
            query = urlparse.urljoin(self.base_link, query)
            link = cloudflare.source(query)
            
            match=re.compile('<h3 class="name"><a href="(.+?)" title=".+?">(.+?)</a></h3>').findall(link)
            for url,name in match:
				name = urllib.quote_plus(name)
				title = urllib.quote_plus(title)
				if title in name:
					return url
        except:
            return	
	   

        

    def sources(self, url, hosthdDict, hostprDict):
        try:
            sources = []
            if url == None: return sources
            result = cloudflare.source(url)
            match = re.compile('src="http://hdpass.link/(.+?)"').findall(result)
            for redirect in match: 
				if "download" not in redirect:
					redirect = "http://hdpass.link/" + redirect
					hdpass = redirect
					result2 = client.source(hdpass)
            playlink = re.compile('<source src="(.+?)" type="video/mp4" data-res="(.+?)"/>', re.DOTALL).findall(result2)
            for url,quality in playlink:
				if "720" in quality:
					quality = 'HD'
				elif '1080' in quality:
					quality = '1080p'
				else: quality = 'SD'
				sources.append({'source': 'gvideo', 'quality': quality, 'provider': 'ItaliafilmVideoHD', 'url': url, 'direct': True, 'debridonly': False})
            return sources
        except:
            return sources 


    def resolve(self, url):
        try:
            url = client.request(url, output='geturl')
            if 'requiressl=yes' in url: url = url.replace('http://', 'https://')
            else: url = url.replace('https://', 'http://')
            return url
        except:
            return




def open_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link

