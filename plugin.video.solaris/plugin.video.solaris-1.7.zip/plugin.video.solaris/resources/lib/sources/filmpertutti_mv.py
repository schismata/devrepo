# -*- coding: utf-8 -*-

'''
    Exodus Add-on
    Copyright (C) 2016 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

domain = 'FILMPERTUTTI'
import re,urllib,urlparse,base64,urlresolver

from resources.lib.modules import cleantitle
from resources.lib.modules import client
import unicodedata

class source:
    def __init__(self):
        self.domains = ['filmpertutti.click']
        self.base_link = 'http://www.filmpertutti.click'
        self.moviesearch_link = '/search/%s'
        
    def movie(self, imdb, title, year):
        try:
            query = self.moviesearch_link % urllib.quote_plus(title)
            query = urlparse.urljoin(self.base_link, query)

            result = client.source(query)
            result = result.decode('iso-8859-1').encode('utf-8')
            title = cleantitle.get(title)              
            match=re.compile('<a href="(.+?)" rel="bookmark" title="(.+?)" target=').findall(result)
            for url,name in match:
				name = cleantitle.get_italian(name)
				name = re.sub('linkto','',name)
				print 'SOLARIS ; %s -> SCRAPED TITLE = %s' % (domain, name)
				if title == name: 
					
					url = url
					print 'SOLARIS UUUUUUUUUUUUUUUUUUUUUUUUUUUUUURL =%s ' % url
					return url
        except:
            return	

    def sources(self, url, hosthdDict, hostprDict):
        try:
            sources = []
            if url == None: return sources
            result = client.source(url)

            playlink = re.compile('<a href="(.+?)" target="_blank" rel="nofollow">.+?</a>', re.DOTALL).findall(result)
            for url in playlink:
				host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
				host = client.replaceHTMLCodes(host)
				host = host.encode('utf-8')
				url = client.replaceHTMLCodes(url)
				url = url.encode('utf-8')

				if "speedvideo" in host:
					quality = 'HD'
				else: quality = 'SD'
				
				
				sources.append({'source': host, 'quality': quality, 'provider': 'Filmpertutti', 'url': url, 'direct': False, 'debridonly': False})
            return sources
        except:
            return sources 


    def resolve(self, url):
       
        return url


