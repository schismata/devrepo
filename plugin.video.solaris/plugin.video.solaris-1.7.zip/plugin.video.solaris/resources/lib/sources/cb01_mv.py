# -*- coding: utf-8 -*-

'''
    Exodus Add-on
    Copyright (C) 2016 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import urllib,urllib2,re,sys,xbmc,xbmcaddon,os,urlparse,base64,net,cf,json
from t0mm0.common.addon import Addon
from metahandler import metahandlers
net = net.Net()
addon_id = 'plugin.video.solaris'
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
addon = Addon(addon_id, sys.argv)
try:os.mkdir(datapath)
except:pass
file_var = open(xbmc.translatePath(os.path.join(datapath, 'cineblog_cookie.lwp')), "a")
cookie_file = os.path.join(os.path.join(datapath,''), 'cineblog_cookie.lwp')

from resources.lib.modules import cleantitle
from resources.lib.modules import cloudflare
from resources.lib.modules import client
import unicodedata
domain = 'CINEBLOG'
class source:
    def __init__(self):
        self.domains = ['cb01.co']
        self.base_link = 'http://www.cb01.co'
        self.watch_link = ''
        self.search_link = '/?s=%s'


    def movie(self, imdb, title, year):
        try:
            
            query = self.search_link % urllib.quote_plus(title)
            query = self.base_link + query
            result = open_url(query)
            title = cleantitle.get(title)  
            result=re.compile('<a href="(.+?)">\s*<h1>(.+?)</h1></a>').findall(result)
            for url,name in result:
				name = cleantitle.get_italian(name)
				print 'SOLARIS ; %s -> SCRAPED TITLE = %s' % (domain, name)
				if title == name: 
					
					url = url
					print 'SOLARIS UUUUUUUUUUUUUUUUUUUUUUUUUUUUUURL =%s ' % url
					return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None: return sources
            result = open_url(url)
		
            match2 = re.compile('<iframe src="(.+?)"').findall(result)
            match = re.compile('<td><a href="(.+?)" target="_blank">.+?</a></td>').findall(result)
            for url in match: 
				if "cineblog" in url:
					link2 = open_url(url)
					matchnew = re.compile('<a href="(.+?)" class="btn-wrapper link" onClick="').findall(link2)
					for url in matchnew:
						host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
						host = client.replaceHTMLCodes(host)
						host = host.encode('utf-8')
						url = client.replaceHTMLCodes(url)
						url = url.encode('utf-8')

						if "videomega" in host:
							quality = 'HD'
						else: quality = 'SD'

						sources.append({'source': host, 'quality': quality, 'provider': 'cb01', 'url': url, 'direct': False, 'debridonly': False})
				elif "swzz.xyz" in url:
					link2 = open_url(url)
					matchnew = re.compile('<a href="(.+?)" class="btn-wrapper link" onClick="', re.DOTALL).findall(link2)
					for url in matchnew:
						host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
						host = client.replaceHTMLCodes(host)
						host = host.encode('utf-8')
						url = client.replaceHTMLCodes(url)
						url = url.encode('utf-8')

						if "videomega" in host:
							quality = 'HD'
						else: quality = 'SD'

						sources.append({'source': host, 'quality': quality, 'provider': 'cb01', 'url': url, 'direct': False, 'debridonly': False})
				else:
						host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
						host = client.replaceHTMLCodes(host)
						host = host.encode('utf-8')
						url = client.replaceHTMLCodes(url)
						url = url.encode('utf-8')

						if "videomega" in host:
							quality = 'HD'
						else: quality = 'SD'

						sources.append({'source': host, 'quality': quality, 'provider': 'cb01', 'url': url, 'direct': False, 'debridonly': False})
			
            return sources
        except:
            return sources 


    def resolve(self, url):
        return url

def open_url(url):
        try:
            net.set_cookies(cookie_file)
            link = net.http_GET(url).content
            return link
        except:
          try:
            cf.solve(url,cookie_file,wait=True)
            net.set_cookies(cookie_file)
            link = net.http_GET(url).content
            return link
          except:
            cf.solve(url,cookie_file,wait=True)
            net.set_cookies(cookie_file)
            link = net.http_GET(url).content
            return link