# -*- coding: utf-8 -*-

'''
    Exodus Add-on
    Copyright (C) 2016 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import urllib,urllib2,re,sys,xbmc,xbmcaddon,os,urlparse,base64,net,cf
from t0mm0.common.addon import Addon
from metahandler import metahandlers
net = net.Net()
addon_id = 'plugin.video.solaris'
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
addon = Addon(addon_id, sys.argv)
try:os.mkdir(datapath)
except:pass
file_var = open(xbmc.translatePath(os.path.join(datapath, 'ifilmvideohd_cookie.lwp')), "a")
cookie_file = os.path.join(os.path.join(datapath,''), 'ifilmvideohd_cookie.lwp')

import json
from resources.lib.modules import cleantitle
from resources.lib.modules import cloudflare
from resources.lib.modules import client
import unicodedata
domain = 'ITALIAFILMVIDEOHD'
class source:
    def __init__(self):
        self.domains = ['italiafilm.video']
        self.base_link = 'http://www.italiafilm.video'
        self.search_link = '/?s=%s'


    def movie(self, imdb, title, year):
        try:
            query = self.search_link % urllib.quote_plus(title)
            query = self.base_link + query
            result = open_url(query)
            title = cleantitle.get(title)  

            result_links = re.compile('<h3 class="name"><a href="(.+?)" title=".+?">(.+?)</a></h3>').findall(result)
            for url,name in result_links:
				name = cleantitle.get_italian(name)
				print 'SOLARIS ; %s -> SCRAPED TITLE = %s' % (domain, name)
				if title in name: 
					
					url = url
					print 'SOLARIS UUUUUUUUUUUUUUUUUUUUUUUUUUUUUURL =%s ' % url
					return url
        except:
            return


    def sources(self, url, hosthdDict, hostprDict):
        try:
            sources = []
            if url == None: return sources
            result = open_url(url)
            match = re.compile('src="http://hdpass.link/(.+?)"').findall(result)
            for redirect in match: 
				if "download" not in redirect:
					redirect = "http://hdpass.link/" + redirect
					hdpass = redirect
					result2 = open_url(hdpass)
            playlink = re.compile('<source src="(.+?)" type="video/mp4" data-res="(.+?)"/>', re.DOTALL).findall(result2)
            playlink_2 = re.compile('<input type="hidden" name="idFilm" value="(.+?)"/>.+?alue="HDPLAY"/>', re.DOTALL).findall(result2)
            # playlink_3 = re.compile('<input type="hidden" name="idFilm" value="(.+?)"/>.+?alue="Tusfile"/>', re.DOTALL).findall(result2)
            for url,quality in playlink:
				if "720" in quality:
					quality = 'HD'
				elif '1080' in quality:
					quality = '1080p'
				else: quality = 'SD'
				sources.append({'source': 'gvideo', 'quality': quality, 'provider': 'IfilmvideoHD', 'url': url, 'direct': True, 'debridonly': False})
            for id in playlink_2:
				rurl = "http://hdpass.link/film.php?play_chosen=google&idFilm=" + id + "&mir_pl=HDPLAY"
				result_rurl = client.source(rurl)
				playr = re.compile('<source src="(.+?)" type="video/mp4" data-res="(.+?)"/>', re.DOTALL).findall(result_rurl)
				for url, quality in playr:
					if "720" in quality:
						quality = 'HD'
					elif '1080' in quality:
						quality = '1080p'
					else: quality = 'SD'
					sources.append({'source': 'gvideo', 'quality': quality, 'provider': 'IfilmvideoHD', 'url': url, 'direct': True, 'debridonly': False})
            # for id in playlink_3:
				# rurl = "http://hdpass.link/film.php?play_chosen=tusfiles&idFilm=" + id + "&mir_pl=Tusfile"
				# result_rurl = client.source(rurl)
				# playr = re.compile('<source src="(.+?)" type="video/mp4" data-res="(.+?)"/>', re.DOTALL).findall(result_rurl)
				# for url, quality in playr:
					# quality = '1080p'
					# sources.append({'source': 'gvideo', 'quality': quality, 'provider': 'IfilmvideoHD', 'url': url, 'direct': True, 'debridonly': False})
            return sources
        except:
            return sources 


    def resolve(self, url):
        try:
            url = client.request(url, output='geturl')
            if 'requiressl=yes' in url: url = url.replace('http://', 'https://')
            else: url = url.replace('https://', 'http://')
            return url
        except:
            return


def open_url(url):
        try:
            net.set_cookies(cookie_file)
            link = net.http_GET(url).content
            return link
        except:
          try:
            cf.solve(url,cookie_file,wait=True)
            net.set_cookies(cookie_file)
            link = net.http_GET(url).content
            return link
          except:
            cf.solve(url,cookie_file,wait=True)
            net.set_cookies(cookie_file)
            link = net.http_GET(url).content
            return link
