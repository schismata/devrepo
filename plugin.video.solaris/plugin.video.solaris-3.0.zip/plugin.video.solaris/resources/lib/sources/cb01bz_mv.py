# -*- coding: utf-8 -*-

'''
    solaris Add-on
    Copyright (C) 2016 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import urllib,urllib2,re,sys,xbmc,xbmcaddon,os,urlparse,base64,net,cf,json
from t0mm0.common.addon import Addon
from metahandler import metahandlers
net = net.Net()
addon_id = 'plugin.video.solaris'
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
addon = Addon(addon_id, sys.argv)
try:os.mkdir(datapath)
except:pass
file_var = open(xbmc.translatePath(os.path.join(datapath, 'cineblogbz_cookie.lwp')), "a")
cookie_file = os.path.join(os.path.join(datapath,''), 'cineblogbz_cookie.lwp')

from resources.lib.modules import cleantitle
from resources.lib.modules import cloudflare
from resources.lib.modules import client
import unicodedata
domain = 'CINEBLOGBZ'
class source:
    def __init__(self):
        self.domains = ['cineblog-01.club']
        self.base_link = 'http://www.cineblog01.bz'
        self.watch_link = ''
        self.search_link = '/?do=search&subaction=search&story=%s'


    def movie(self, imdb, title, year):
        try:
            query = self.search_link % urllib.quote_plus(title)
            query = self.base_link + query
            result = open_url(query)
            title = cleantitle.get(title)  
            match = re.compile('<div class="post-title"><a href="(.+?)">(.+?)</a></div>').findall(result)[:3]
            for url,name in match:
				name = cleantitle.get_italian(name)
				print 'SOLARIS ; %s -> SCRAPED TITLE = %s' % (domain, name)
				if title == name: 
					print 'SOLARIS UUUUUUUUUUUUUUUUUUUUUUUUUUUUUURL =%s ' % url
					return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None: return sources
            result = open_url(url)
		
            match = re.compile('<iframe src="(.+?)" width=').findall(result)
            for url in match: 
					if "youtube" not in url:
						host = re.findall('([\w]+[.][\w]+)$', urlparse.urlparse(url.strip().lower()).netloc)[0]
						host = client.replaceHTMLCodes(host)
						host = host.encode('utf-8')
						url = client.replaceHTMLCodes(url)
						url = url.encode('utf-8')
						quality = 'SD'
						sources.append({'source': host, 'quality': quality, 'provider': 'cb01bz', 'url': url, 'direct': False, 'debridonly': False})

			
            return sources
        except:
            return sources 


    def resolve(self, url):
        return url

def open_url(url):
        try:
            net.set_cookies(cookie_file)
            link = net.http_GET(url).content
            return link
        except:
          try:
            cf.solve(url,cookie_file,wait=True)
            net.set_cookies(cookie_file)
            link = net.http_GET(url).content
            return link
          except:
            cf.solve(url,cookie_file,wait=True)
            net.set_cookies(cookie_file)
            link = net.http_GET(url).content
            return link