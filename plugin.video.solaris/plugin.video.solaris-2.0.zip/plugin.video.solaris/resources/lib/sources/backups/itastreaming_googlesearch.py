# -*- coding: utf-8 -*-

'''
    solaris Add-on
    Copyright (C) 2016 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
##### ITASTREAMING ########

import re,urllib,urlparse,json,base64

from resources.lib.modules import cleantitle
from resources.lib.modules import pyaes
from resources.lib.modules import cloudflare
from resources.lib.modules import client
from resources.lib.modules import directstream


class source:
    def __init__(self):
        self.domains = ['itastreaming.co']
        self.base_link = 'http://itastreaming.co'
        self.watch_link = ''
        self.search_link = 'https://www.googleapis.com/customsearch/v1element?key=AIzaSyCVAXiUzRYsML1Pv6RwSG1gunmMikTzQqY&rsz=filtered_cse&num=10&hl=en&cx=006089819215786116536:8xiysdoj76a&googlehost=www.google.com&q='


    def movie(self, imdb, title, year):
        try:
            query = title.replace(':', '').replace(' ','%20')
            query = self.search_link + query
            result = client.source(query)
            result = json.loads(result)['results']
            result = [(i['url'], i['richSnippet']['movie']['name']) for i in result if 'richSnippet' in i and 'movie' in i['richSnippet'] and 'name' in i['richSnippet']['movie']]
            for url,name in result:
				
				
				if title in name:
					url = url
					return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None: return sources
            result = cloudflare.source(url)
            match = re.compile('src="http://hdpass.link/(.+?)"').findall(result)
            for redirect in match: 
				if "download" not in redirect:
					redirect = "http://hdpass.link/" + redirect
					hdpass = redirect
					result2 = cloudflare.source(hdpass)
            playlink = re.compile('<source src="(.+?)" type="video/mp4" data-res="(.+?)"/>', re.DOTALL).findall(result2)
            for url,quality in playlink:
				if "720" in quality:
					quality = 'HD'
				elif '1080' in quality:
					quality = '1080p'
				else: quality = 'SD'
				sources.append({'source': 'gvideo', 'quality': quality, 'provider': 'Itastreaming', 'url': url, 'direct': True, 'debridonly': False})
            return sources
        except:
            return sources 


    def resolve(self, url):
        try:
            url = client.request(url, output='geturl')
            if 'requiressl=yes' in url: url = url.replace('http://', 'https://')
            else: url = url.replace('https://', 'http://')
            return url
        except:
            return


