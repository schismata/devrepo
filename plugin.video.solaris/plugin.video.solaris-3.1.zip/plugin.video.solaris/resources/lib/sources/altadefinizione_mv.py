# -*- coding: utf-8 -*-

'''
    solaris Add-on
    Copyright (C) 2016 lambda

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import urllib,urllib2,re,sys,xbmc,xbmcaddon,os,urlparse,base64,net,cf
from t0mm0.common.addon import Addon
from metahandler import metahandlers
net = net.Net()
addon_id = 'plugin.video.solaris'
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
addon = Addon(addon_id, sys.argv)
try:os.mkdir(datapath)
except:pass
file_var = open(xbmc.translatePath(os.path.join(datapath, 'altadefinizione_cookie.lwp')), "a")
cookie_file = os.path.join(os.path.join(datapath,''), 'altadefinizione_cookie.lwp')

import json
from resources.lib.modules import cleantitle
from resources.lib.modules import cloudflare
from resources.lib.modules import client
import unicodedata
domain = 'ALTADEFINIZIONE'
class source:
    def __init__(self):
        self.domains = ['altadefinizione.online']
        self.base_link = 'http://altadefinizione.online'
        self.watch_link = ''
        self.search_link = '/?s=%s'


    def movie(self, imdb, title, year):
        try:
			
            query = self.search_link % urllib.quote_plus(title)
            query = self.base_link + query
            result = open_url(query)
            title = cleantitle.get(title)  
            scrape = '<div class="col-lg-3 col-md-3 col-xs-3">.*?'
            scrape += 'href="([^"]+)".*?'
            scrape += 'class="titleFilm">([^<]+)<.*?'
            result_links = re.compile(scrape, re.DOTALL).findall(result)
            for url,name in result_links:
				name = cleantitle.get_italian(name)
				print 'SOLARIS ; %s -> SCRAPED TITLE = %s' % (domain, name)
				if title == name: 
					
					url = url
					print 'SOLARIS UUUUUUUUUUUUUUUUUUUUUUUUUUUUUURL =%s ' % url
					return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None: return sources
            result = open_url(url)
            match = re.compile('<ifram.+?rc="(.+?)".+?/iframe>').findall(result)
            for redirect in match: 
				if "hdpass" in redirect:
					if "download" not in redirect:
						result2 = open_url(redirect)
						playlink_2 = re.compile('<input type="hidden" name="play_chosen" value="(.+?)"/>\s*<input type="hidden" name="idFilm" value="(.+?)"/>.+?nput type="hidden" name="res" value="(.+?)"/>.+?nput type="submit.+?ame="mir_pl" value="(.+?)"/>').findall(result2)
						for hostid,idfilm,res,player in playlink_2:
							playurl = "http://hdpass.xyz/film.php?play_chosen=%s&idFilm=%s&res=%s&mir_pl=%s" % (hostid,idfilm,res,player)
							finalurl = open_url(playurl)
							playlink_3 = re.compile('id="urlEmbed" value="(.+?)"/>', re.DOTALL).findall(finalurl)
							for url in playlink_3:
								url = client.replaceHTMLCodes(url)
								url = url.encode('utf-8')
								quality = "1080p"
								host = "gvideo"
								sources.append({'source': host, 'quality': quality, 'provider': 'altadefinizione', 'url': url, 'direct': False, 'debridonly': False})
            return sources
        except:
            return sources 


    def resolve(self, url):
        try:
            url = client.request(url, output='geturl')
            if 'requiressl=yes' in url: url = url.replace('http://', 'https://')
            else: url = url.replace('https://', 'http://')
            return url
        except:
            return

def open_url(url):
        try:
            net.set_cookies(cookie_file)
            link = net.http_GET(url).content
            return link
        except:
          try:
            cf.solve(url,cookie_file,wait=True)
            net.set_cookies(cookie_file)
            link = net.http_GET(url).content
            return link
          except:
            cf.solve(url,cookie_file,wait=True)
            net.set_cookies(cookie_file)
            link = net.http_GET(url).content
            return link