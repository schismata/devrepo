import urllib2,urllib,re,os
import sys
import urlresolver
import xbmcplugin,xbmcgui,xbmc, xbmcaddon, downloader, extract, time
import tools
from libs import kodi
from tm_libs import dom_parser
from libs.trans_utils import i18n
from libs import log_utils
from t0mm0.common.net import Net
from t0mm0.common.addon import Addon
import main_scrape
from urllib2 import Request, build_opener, HTTPCookieProcessor, HTTPHandler
import cookielib
net = Net()
addon_id=kodi.addon_id
addon = Addon(addon_id, sys.argv)

#COOKIE STUFF
tools.create_directory(tools.AOPATH, "All_Cookies/moviehdmax")
cookiepath = xbmc.translatePath(os.path.join('special://home','addons',addon_id,'All_Cookies','moviehdmax/'))
cookiejar = os.path.join(cookiepath,'cookies.lwp')
cj = cookielib.LWPCookieJar()
cookie_file = os.path.join(cookiepath,'cookies.lwp')

base_url = 'http://moviehdmax.com/'

def LogNotify(title,message,times,icon):
		xbmc.executebuiltin("XBMC.Notification("+title+","+message+","+times+","+icon+")")

def OPEN_URL(url):
  req=urllib2.Request(url)
  req.add_header('User-Agent', 'Mozilla/5.0 (Linux; U; Android 4.2.2; en-us; AFTB Build/JDQ39) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
  response=urllib2.urlopen(req)
  link=response.read()
  cj.save(cookie_file, ignore_discard=True)
  response.close()
  return link

def moviehdmax(name):
    sources = []
    searchUrl = 'http://moviehdmax.com/search/result?s='
    movie_name = name[:-6]
    movie_name_short = name[:-7]
    movie_year = name[-6:]
    movie_year = movie_year.replace('(','').replace(')','')
    sname = movie_name_short.replace(" ","+")
    mername = sname[:-1]
    movie_match =movie_name.replace(" ","_")+movie_year
    surl = searchUrl + sname + "&selected=false"
    link = OPEN_URL(surl)
    match=re.compile('<p class="txt4">\s*<a href="../(.+?)">(.+?)</a>').findall(link)[:1]
    for url, name in match:
         if movie_match in url or movie_name_short in name:
            origname = name
            link = OPEN_URL(base_url+url)
            # vidlinks=dom_parser.parse_dom(link, 'span',{'class':"movie_version_link"})
            # linknames=dom_parser.parse_dom(link, 'span',{'class':"version_host"})
            match=re.compile('''<source src="(.+?)" type='.+?' data-res="(.+?)"/>''').findall(link)
            for vidlink, name in match:
			 
                    

						
                        url = vidlink
                        #print "URLS IS = " +url
                        # name = name.replace("'","")
                        linkname = "MOVIEHDMAX" + "  " + origname + " " + name + "p"
                        source = {'url': url, 'linkname': linkname}
                        sources.append(source)
    return sources



def playmoviehdmaxlink(url,name,thumb):
	     
	resp = urllib2.urlopen(url)
	url2 = resp.geturl()
	stream_url = urlresolver.HostedMediaFile(url2).resolve()
	liz=xbmcgui.ListItem(name, iconImage=thumb, thumbnailImage=thumb); liz.setInfo( type="Video", infoLabels={ "Title": name } )
	xbmc.Player ().play(stream_url,liz)
	addLink("Press Back to exit",url,'',thumb,thumb)
	
	# kodi.addDir("[MOVIEHDMAX] - Go Back "+name,'','',thumb,name,'','','movies',menu_items='')


def addLink(name,url,mode,iconimage,description=''):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description} )
        
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
